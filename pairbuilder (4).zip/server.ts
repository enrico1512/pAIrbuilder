import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // --- Diagnostic Endpoint ---
  app.get("/api/config-check", (req, res) => {
    const hasVision = !!process.env.GOOGLE_CLOUD_VISION_API_KEY;
    const hasOpenAI = !!process.env.OPENAI_API_KEY;
    
    res.json({
      visionApiKeyPresent: hasVision,
      openaiApiKeyPresent: hasOpenAI,
      status: (hasVision && hasOpenAI) ? "Ready" : "Partial Configuration",
      message: `${hasVision ? "✅ Vision" : "❌ Vision"} | ${hasOpenAI ? "✅ OpenAI" : "❌ OpenAI"}`
    });
  });

  // --- API Proxy for Google Cloud Vision (Secures the API Key) ---
  app.post("/api/vision/ocr", async (req, res) => {
    const { image } = req.body;
    const API_KEY = process.env.GOOGLE_CLOUD_VISION_API_KEY;

    if (!API_KEY) {
      console.warn("GOOGLE_CLOUD_VISION_API_KEY not found in environment.");
      return res.status(500).json({ error: "Missing Vision API Key on server." });
    }

    try {
      const response = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${API_KEY}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requests: [
            {
              image: { content: image },
              features: [{ type: "DOCUMENT_TEXT_DETECTION" }],
              imageContext: { languageHints: ["it"] }
            }
          ]
        })
      });

      const data = await response.json();

      if (!response.ok) {
        console.error("Google Vision API Error Response:", data);
        return res.status(response.status).json({ 
          error: data.error?.message || "Google Vision API error",
          code: response.status,
          details: data.error?.details || null
        });
      }

      // Log successful OCR text length and first 100 chars
      const text = data.responses[0]?.fullTextAnnotation?.text || "";
      console.log(`[OCR SUCCESS] Extracted ${text.length} characters. Preview: ${text.substring(0, 100)}...`);
      
      res.json(data);
    } catch (error) {
      console.error("Server OCR Exception:", error);
      res.status(500).json({ error: "OCR operation failed on server due to an internal exception." });
    }
  });

  // --- API Proxy for OpenAI Extraction ---
  app.post("/api/openai/extract", async (req, res) => {
    const { prompt, data, image } = req.body;
    const API_KEY = process.env.OPENAI_API_KEY;

    if (!API_KEY) {
      return res.status(500).json({ error: "Missing OpenAI API Key on server." });
    }

    try {
      const messages: any[] = [
        {
          role: "system",
          content: "Sei un esperto sommelier e digitalizzatore di menu. Rispondi sempre in formato JSON valido."
        },
        {
          role: "user",
          content: [
            { type: "text", text: prompt + (data ? `\n\nCONTENUTO TESTUALE:\n${data}` : "") }
          ]
        }
      ];

      if (image) {
        messages[1].content.push({
          type: "image_url",
          image_url: { url: `data:image/jpeg;base64,${image}` }
        });
      }

      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${API_KEY}`
        },
        body: JSON.stringify({
          model: "gpt-4o",
          messages,
          response_format: { type: "json_object" },
          temperature: 0
        })
      });

      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error?.message || "OpenAI API error");
      }

      res.json(JSON.parse(result.choices[0].message.content));
    } catch (error) {
      console.error("OpenAI Extraction Error:", error);
      res.status(500).json({ error: error instanceof Error ? error.message : "Extraction failed" });
    }
  });

  app.post("/api/openai/list-items", async (req, res) => {
    const { prompt, data, image } = req.body;
    const API_KEY = process.env.OPENAI_API_KEY;

    if (!API_KEY) {
      return res.status(500).json({ error: "Missing OpenAI API Key on server." });
    }

    try {
      const messages: any[] = [
        {
          role: "system",
          content: "Sei un assistente AI specializzato nel rilevamento di voci in menu di ristoranti. Rispondi in JSON."
        },
        {
          role: "user",
          content: [
            { type: "text", text: prompt + (data ? `\n\nCONTENUTO TESTUALE:\n${data}` : "") }
          ]
        }
      ];

      if (image) {
        messages[1].content.push({
          type: "image_url",
          image_url: { url: `data:image/jpeg;base64,${image}` }
        });
      }

      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${API_KEY}`
        },
        body: JSON.stringify({
          model: "gpt-4o-mini", // Mini is enough for simple listing
          messages,
          response_format: { type: "json_object" },
          temperature: 0
        })
      });

      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error?.message || "OpenAI API error");
      }

      res.json(JSON.parse(result.choices[0].message.content));
    } catch (error) {
      console.error("OpenAI List Items Error:", error);
      res.status(500).json({ error: error instanceof Error ? error.message : "Listing failed" });
    }
  });

  // --- Vite Middleware ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
